({
	doVarify : function(component, event, helper) {
		var appEvent = $A.get("e.c:interNSEvent");
        appEvent.setParams({ "calcSum" : component.get("v.sum") })
		appEvent.fire();
	}
})