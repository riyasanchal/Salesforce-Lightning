({
	showSum : function(component, event, helper) {
        var params = {
            "number1" : component.get("v.number1"),
            "number2" : component.get("v.number2"),
            "sum" : component.get("v.number1") + component.get("v.number2")
        }
        helper.addChildToparent(component, 'c:NamespaceChild', params);
	},
    
    showVarifyResult : function(component, event, helper) {
         var calcSum = event.getParam("calcSum");

        // set the handler attributes based on event data
        component.set("v.sum", calcSum);        
    }
})