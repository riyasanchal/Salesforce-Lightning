({
	addChildToparent : function(component, modelComponent, params) {
        $A.createComponent(
            modelComponent, 
            params,
            function(componentBody){                
                if (component.isValid()) {
                    var targetCmp = component.find('resultConatiner');
                    var body = targetCmp.get("v.body");
                    body.push(componentBody);
                    targetCmp.set("v.body", body); 
                }
            }
        );
    },
})